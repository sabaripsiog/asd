﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crud
{
    public class Bill2
    {
        public int unitPerMonth { get; set; }
        public double RupeesPerUnit { get; set; }
        public double Total { get; set; }
    }
}
